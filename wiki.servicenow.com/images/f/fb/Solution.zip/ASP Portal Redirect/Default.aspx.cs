using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void go_to(object sender, EventArgs e)
    {
        try
        {
            HttpCookie myCookie = new HttpCookie("SM_USER");
            myCookie.Value = userNameBox.Text;
            Response.Cookies.Add(myCookie);
            Response.AppendHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            Response.Redirect(urlBox.Text);

        }catch {} 
    }
}
